SELECT *
FROM `heymax-kelvin-analytics.heymax_analytics.event_stream_raw`
